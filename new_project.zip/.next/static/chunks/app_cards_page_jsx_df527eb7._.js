(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_swiper_3ebc3ea4._.js",
  "static/chunks/node_modules_next_15251bc2._.js",
  "static/chunks/node_modules_react-icons_abe275b9._.js",
  "static/chunks/node_modules_framer-motion_dist_es_5e916064._.js",
  "static/chunks/node_modules_motion-dom_dist_es_0da7774d._.js",
  "static/chunks/node_modules_f2072521._.js",
  "static/chunks/_6a9183cb._.js",
  "static/chunks/_04933641._.css"
],
    source: "dynamic"
});
