(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_f5a46f3f._.js",
  "static/chunks/_d4a7ca47._.js"
],
    source: "dynamic"
});
