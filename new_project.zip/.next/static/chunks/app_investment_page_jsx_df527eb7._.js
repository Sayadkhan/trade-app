(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_axios_lib_99999129._.js",
  "static/chunks/node_modules_next_f346a4c4._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_b854acb4._.js",
  "static/chunks/node_modules_react-icons_abe275b9._.js",
  "static/chunks/node_modules_99fc2624._.js",
  "static/chunks/_e25855e8._.js"
],
    source: "dynamic"
});
