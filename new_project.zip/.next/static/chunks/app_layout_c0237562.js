(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__501b62d3._.css",
  "static/chunks/node_modules_@tanstack_query-devtools_build_751470da._.js",
  "static/chunks/node_modules_71e9b7b4._.js",
  "static/chunks/_ba783027._.js"
],
    source: "dynamic"
});
