(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_15251bc2._.js",
  "static/chunks/node_modules_react-icons_io_index_mjs_d35cf443._.js",
  "static/chunks/node_modules_react-icons_hi_index_mjs_d2378608._.js",
  "static/chunks/node_modules_react-icons_ci_index_mjs_e4544c82._.js",
  "static/chunks/node_modules_react-icons_ri_index_mjs_0e2ec0a5._.js",
  "static/chunks/node_modules_react-icons_fa6_index_mjs_00e856c4._.js",
  "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7f5._.js",
  "static/chunks/node_modules_react-icons_lib_74ccc930._.js",
  "static/chunks/node_modules_swiper_f0e3eb12._.js",
  "static/chunks/_0fb141c7._.js",
  "static/chunks/node_modules_swiper_b167c7bf._.css"
],
    source: "dynamic"
});
