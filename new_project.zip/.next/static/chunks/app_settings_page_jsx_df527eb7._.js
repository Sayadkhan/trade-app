(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_47e1cffd._.js",
  "static/chunks/_6c7d6b07._.js"
],
    source: "dynamic"
});
