import Navbar from '@/components/navbar/navbar'
import Profile from '@/features/Profile'
import React from 'react'

const page = () => {
  return (
    <div>
      <div>
        <Navbar/>
      </div>
  <div>
    <Profile/>
  </div>
    </div>
  )
}

export default page
