// components/sidebar/SidebarWrapper.js
"use client";

import Sidebar from "../sidebar/Sidebar";

export default function SidebarWrapper() {
  return <Sidebar />;
}
